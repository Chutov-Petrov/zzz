﻿using System;
using System.Data;
using System.Data.SQLite;
using System.IO;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace SupportDesk.forms
{
    public partial class ForgotPasswordForm : Form
    {
        #region Настройки формы
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;
        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();
        #endregion
        #region Локальные переменные
        private SQLiteConnection DB;
        #endregion
        public ForgotPasswordForm()
        {
            InitializeComponent();
        }
        private async void ForgotPasswordForm_Load(object sender, EventArgs e)
        {
            DB = new SQLiteConnection(Database.connectionString);
            await DB.OpenAsync();
        }
        #region Выход
        private void ButtonCancel_Click(object sender, EventArgs e)
        {
            Close();
            DataRequests.IsOpen = false;
        }
        #endregion
        #region Отправить письмо
        private async void ButtonSendPass_Click(object sender, EventArgs e)
        {
            string loginUser = textBoxLogin.Text;
            string emailUser = textBoxMail.Text;
            DataTable table = new DataTable();
            SQLiteDataAdapter adapter = new SQLiteDataAdapter();
            SQLiteDataReader sqlReader = null;
            SQLiteCommand command = new SQLiteCommand($"SELECT * FROM [{Table_users.main}] WHERE [{Table_users.login}] = '" + loginUser + $"' AND [{Table_users.email}] = '" + emailUser + "'", DB);
            try
            {
                adapter.SelectCommand = command;
                _ = adapter.Fill(table);
                if (table.Rows.Count > 0)
                {
                    sqlReader = (SQLiteDataReader)await command.ExecuteReaderAsync();
                    while (await sqlReader.ReadAsync())
                    {
                        string name = sqlReader[$"{Table_users.name}"].ToString();
                        string father = sqlReader[$"{Table_users.father}"].ToString();
                        string login = sqlReader[$"{Table_users.login}"].ToString();
                        string pass = sqlReader[$"{Table_users.pass}"].ToString();
                        Email.CheckEmail(emailUser, name, father, login, pass);
                        MessageBoxUI.Show("Отправлено письмо о восстановлении доступа к программе!", "Восстановление доступа", "Accept");
                        File.AppendAllText(Logs.file, $"[Пользователи]Отправлено письмо доступа {name} {father} (ЗАБЫЛИ ПАРОЛЬ)");
                        File.AppendAllText(Logs.file, Environment.NewLine);
                        Close();
                        DataRequests.IsOpen = false;
                    }
                }
                else
                {
                    MessageBoxUI.Show("Пользователя с такой почтой не существует!", "Ошибка восстановления", "Error");
                }
            }
            catch (Exception ex)
            {
                MessageBoxUI.Show($"{ex.Message}", $"{ex.Source}", "Error");
            }
            finally
            {
                sqlReader?.Close();
            }
        }
        #endregion
        #region Управление формой
        private void FormControl(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                _ = ReleaseCapture();
                _ = SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }
        #endregion
        #region Проверка почты на валидность
        private void TextBoxMail_TextChanged(object sender, EventArgs e)
        {
            textBoxMail.Text = Regex.Replace(textBoxMail.Text, "[^A-Za-z0-9@.]", "");
        }
        #endregion
    }
}