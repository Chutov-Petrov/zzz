﻿using System;
using System.Data;
using System.Data.SQLite;
using System.Windows.Forms;

namespace SupportDesk.forms
{
    public partial class AnalyticsForm : Form
    {
        public AnalyticsForm()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            try
            {
                using (var conn = new SQLiteConnection(Database.connectionString))
                {
                    conn.Open();
                    var dt = new DataTable();
                    using (var adapter = new SQLiteDataAdapter("SELECT * FROM Requests", conn))
                    {
                        adapter.Fill(dt);
                    }
                    _grid.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки данных:\n" + ex.Message,
                    "Аналитика", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
